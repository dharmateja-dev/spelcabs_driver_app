class LanguageModel {
  String? image;
  String? code;
  bool? isDeleted;
  bool? enable;
  String? name;
  String? id;
  bool? isRtl;
  bool? isDefault;

  LanguageModel(
      {this.image,
      this.code,
      this.isDeleted,
      this.enable,
      this.name,
      this.id,
      this.isRtl,
      this.isDefault});

  LanguageModel.fromJson(Map<String, dynamic> json) {
    image = json['image'] ?? '';
    code = json['code'];
    isDeleted = json['isDeleted'];
    enable = json['enable'];
    name = json['name'];
    id = json['id'];
    isRtl = json['isRtl'];
    isDefault = json['isDefault'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['image'] = image;
    data['code'] = code;
    data['isDeleted'] = isDeleted;
    data['enable'] = enable;
    data['name'] = name;
    data['id'] = id;
    data['isRtl'] = isRtl;
    data['isDefault'] = isDefault;
    return data;
  }

  factory LanguageModel.defaultLanguage() {
    return LanguageModel(
      code: 'en',
      name: 'English',
      image: '',
      isRtl: false,
      enable: true,
      isDeleted: false,
      isDefault: true,
      id: '',
    );
  }
}
